/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   custom_mutex_test.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sxhondo <sxhondo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/15 19:20:46 by sxhondo           #+#    #+#             */
/*   Updated: 2021/02/17 11:07:54 by sxhondo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "malloc.h"
#include <stdio.h>

#define NUM_THREADS 100

void		print(char *s)
{
	write(1, s, strlen(s));
}

void		*malloc_thread(void)
{
	char	*t;
	void	*v;
	void	*c;

	t = malloc(1);
	t = realloc(t, 1);
	t = realloc(t, 10);
	t[0] = 'Z';
	t[9] = 'Z';
	t = realloc(t, TINY_ZONE_CHUNK);
	t = realloc(t, TINY_ZONE_CHUNK);
	t = realloc(t, SMALL_ZONE_CHUNK);
	t = realloc(t, 10);
	v = malloc(4096);
	c = calloc(1024, 3);
	free(v);
	free(c);
	free(t);
	return (NULL);
}

int			main(void)
{
	int i;
	pthread_t threads[NUM_THREADS];

	for (int i = 0; i < NUM_THREADS; i++) 
	{
		int status = pthread_create(&threads[i], NULL, (void *)malloc_thread, NULL);
		if (status) {
			write(1, "error\n", 6);
			return 1;
		}
	}

	for (int i = 0; i < NUM_THREADS; i++) 
	{
		int status = pthread_join(threads[i], NULL);
		if (status) {
			write(1, "error\n", 6);
			return 1;
		}
	}

	malloc(4096);
}
